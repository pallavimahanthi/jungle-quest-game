export type GameStatus = "ready" | "playing" | "won" | "lost";

export interface GameSnapshot {
  status: GameStatus;
  score: number;
  health: number;
  coinsCollected: number;
  coinsTotal: number;
  timeSeconds: number;
}

export interface JungleGameController {
  start(): void;
  restart(): void;
  destroy(): void;
}

const WIDTH = 960;
const HEIGHT = 540;
const LEVEL_WIDTH = 3520;
const GROUND_Y = 476;
const PLAYER_WIDTH = 34;
const PLAYER_HEIGHT = 50;

interface Platform {
  x: number;
  y: number;
  width: number;
  height: number;
}

interface Coin {
  x: number;
  y: number;
  collected: boolean;
  phase: number;
}

interface Enemy {
  x: number;
  y: number;
  min: number;
  max: number;
  speed: number;
  direction: number;
  phase: number;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  color: string;
  size: number;
}

const platforms: Platform[] = [
  { x: -100, y: GROUND_Y, width: LEVEL_WIDTH + 200, height: 120 },
  { x: 345, y: 392, width: 172, height: 20 },
  { x: 744, y: 337, width: 180, height: 20 },
  { x: 1138, y: 405, width: 170, height: 20 },
  { x: 1500, y: 350, width: 198, height: 20 },
  { x: 1880, y: 392, width: 174, height: 20 },
  { x: 2250, y: 350, width: 196, height: 20 },
  { x: 2630, y: 386, width: 188, height: 20 },
  { x: 3024, y: 342, width: 190, height: 20 },
];

const coinPositions: Array<[number, number]> = [
  [240, 420], [385, 350], [463, 342], [548, 419],
  [790, 295], [876, 295], [1004, 420], [1170, 360],
  [1250, 356], [1416, 420], [1542, 306], [1634, 306],
  [1790, 420], [1930, 348], [2010, 347], [2160, 420],
  [2296, 286], [2390, 286], [2538, 420], [2674, 341],
  [2762, 341], [2910, 420], [3070, 296], [3160, 296],
];

const enemyHomes = [
  { x: 590, min: 570, max: 690, y: GROUND_Y - 28, speed: 54 },
  { x: 995, min: 940, max: 1110, y: GROUND_Y - 28, speed: 68 },
  { x: 1360, min: 1320, max: 1460, y: GROUND_Y - 28, speed: 58 },
  { x: 1715, min: 1708, max: 1855, y: GROUND_Y - 48, speed: 52 },
  { x: 2100, min: 2070, max: 2230, y: GROUND_Y - 28, speed: 67 },
  { x: 2500, min: 2460, max: 2610, y: GROUND_Y - 28, speed: 62 },
  { x: 2875, min: 2825, max: 3000, y: GROUND_Y - 28, speed: 70 },
];

const trees = Array.from({ length: 30 }, (_, i) => ({
  x: 50 + i * 123,
  height: 124 + ((i * 47) % 76),
  width: 30 + ((i * 13) % 19),
  hue: i % 3,
}));

const rocks = [
  [182, 452, 28], [658, 454, 33], [1088, 451, 24], [1465, 452, 30],
  [1828, 453, 35], [2180, 453, 25], [2595, 451, 32], [2980, 453, 25],
  [3380, 453, 34],
];

const clamp = (value: number, min: number, max: number) =>
  Math.max(min, Math.min(max, value));

const roundedRect = (
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  width: number,
  height: number,
  radius: number,
) => {
  ctx.beginPath();
  ctx.roundRect(x, y, width, height, radius);
};

export function createJungleGame(
  canvas: HTMLCanvasElement,
  onStateChange: (snapshot: GameSnapshot) => void,
): JungleGameController {
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("This browser does not support the game canvas.");

  const coins: Coin[] = coinPositions.map(([x, y], index) => ({
    x,
    y,
    collected: false,
    phase: index * 0.82,
  }));
  const enemies: Enemy[] = enemyHomes.map((enemy, index) => ({
    ...enemy,
    direction: index % 2 === 0 ? 1 : -1,
    phase: index * 1.9,
  }));
  const keys = new Set<string>();
  let status: GameStatus = "ready";
  let score = 0;
  let health = 3;
  let timeSeconds = 0;
  let cameraX = 0;
  let elapsed = 0;
  let hitCooldown = 0;
  let invulnerable = 0;
  let lastFrame = 0;
  let lastPublishedSecond = -1;
  let frameId = 0;
  let disposed = false;
  let player = { x: 76, y: GROUND_Y - PLAYER_HEIGHT, vx: 0, vy: 0, grounded: true, facing: 1 };
  const particles: Particle[] = [];

  const snapshot = (): GameSnapshot => ({
    status,
    score,
    health,
    coinsCollected: coins.filter((coin) => coin.collected).length,
    coinsTotal: coins.length,
    timeSeconds,
  });

  const publish = () => onStateChange(snapshot());

  const reset = (begin: boolean) => {
    status = begin ? "playing" : "ready";
    score = 0;
    health = 3;
    elapsed = 0;
    timeSeconds = 0;
    cameraX = 0;
    hitCooldown = 0;
    invulnerable = 0;
    lastPublishedSecond = -1;
    player = { x: 76, y: GROUND_Y - PLAYER_HEIGHT, vx: 0, vy: 0, grounded: true, facing: 1 };
    keys.clear();
    particles.length = 0;
    coins.forEach((coin) => (coin.collected = false));
    enemies.forEach((enemy, index) => {
      enemy.x = enemyHomes[index].x;
      enemy.direction = index % 2 === 0 ? 1 : -1;
    });
    publish();
  };

  const resize = () => {
    const rect = canvas.getBoundingClientRect();
    if (!rect.width) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    canvas.width = Math.round(rect.width * dpr);
    canvas.height = Math.round((rect.width * HEIGHT / WIDTH) * dpr);
    ctx.setTransform(
      (canvas.width / WIDTH),
      0,
      0,
      (canvas.width / WIDTH),
      0,
      0,
    );
  };

  const onKeyDown = (event: KeyboardEvent) => {
    const key = event.key.toLowerCase();
    const isGameKey = ["arrowleft", "arrowright", "a", "d", " ", "spacebar"].includes(key);
    if (isGameKey) event.preventDefault();
    if (event.repeat) return;
    keys.add(key);
    if (status === "ready" && (key === " " || key === "spacebar")) {
      reset(true);
    } else if (status === "playing" && (key === " " || key === "spacebar") && player.grounded) {
      player.vy = -720;
      player.grounded = false;
    }
  };

  const onKeyUp = (event: KeyboardEvent) => {
    const key = event.key.toLowerCase();
    keys.delete(key);
  };

  const onBlur = () => {
    keys.clear();
  };

  const drawBackground = (time: number) => {
    const sky = ctx.createLinearGradient(0, 0, 0, HEIGHT);
    sky.addColorStop(0, "#8ce1d0");
    sky.addColorStop(0.52, "#baf0bc");
    sky.addColorStop(1, "#e6efab");
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    // Warm canopy light and distant layers make the side-scrolling depth legible.
    const sun = ctx.createRadialGradient(740, 104, 10, 740, 104, 190);
    sun.addColorStop(0, "rgba(255, 244, 171, .72)");
    sun.addColorStop(1, "rgba(255, 244, 171, 0)");
    ctx.fillStyle = sun;
    ctx.fillRect(510, 0, 450, 310);

    ctx.fillStyle = "#80c996";
    ctx.beginPath();
    ctx.moveTo(0, 360);
    for (let x = 0; x <= WIDTH + 28; x += 28) {
      const worldX = x + cameraX * 0.16;
      ctx.lineTo(x, 335 + Math.sin(worldX * 0.008) * 24 + Math.sin(worldX * 0.019) * 10);
    }
    ctx.lineTo(WIDTH, 476);
    ctx.lineTo(0, 476);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#56a96f";
    ctx.beginPath();
    ctx.moveTo(0, 415);
    for (let x = 0; x <= WIDTH + 34; x += 34) {
      const worldX = x + cameraX * 0.32;
      ctx.lineTo(x, 382 + Math.sin(worldX * 0.012) * 16 + Math.sin(worldX * 0.028) * 8);
    }
    ctx.lineTo(WIDTH, 476);
    ctx.lineTo(0, 476);
    ctx.closePath();
    ctx.fill();

    // Soft drifting fireflies keep the sky from feeling static.
    for (let i = 0; i < 12; i++) {
      const x = (i * 103 + time * (7 + i % 4) + cameraX * 0.12) % (WIDTH + 10);
      const y = 100 + (i * 53) % 255 + Math.sin(time * 1.7 + i) * 9;
      ctx.fillStyle = `rgba(255, 244, 146, ${0.45 + Math.sin(time * 3 + i) * 0.2})`;
      ctx.beginPath();
      ctx.arc(x, y, 2.2, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  const drawTree = (tree: (typeof trees)[number], time: number) => {
    const screenX = tree.x - cameraX * 0.72;
    if (screenX < -100 || screenX > WIDTH + 100) return;
    const top = 435 - tree.height;
    ctx.fillStyle = "#725133";
    roundedRect(ctx, screenX - tree.width * 0.16, top + 22, tree.width * 0.32, tree.height, 8);
    ctx.fill();
    ctx.fillStyle = "#94643b";
    roundedRect(ctx, screenX - tree.width * 0.08, top + 35, tree.width * 0.08, tree.height - 38, 4);
    ctx.fill();

    const sway = Math.sin(time * 0.8 + tree.x) * 2.2;
    const colors = ["#21966d", "#33a978", "#16875f"];
    const crownColor = colors[tree.hue];
    ctx.fillStyle = crownColor;
    ctx.beginPath();
    ctx.ellipse(screenX + sway, top + 22, tree.width * 1.1, 31, 0, 0, Math.PI * 2);
    ctx.ellipse(screenX - tree.width * 0.52 + sway, top + 34, tree.width * 0.72, 25, 0, 0, Math.PI * 2);
    ctx.ellipse(screenX + tree.width * 0.52 + sway, top + 35, tree.width * 0.78, 26, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "rgba(115, 219, 125, .48)";
    ctx.beginPath();
    ctx.ellipse(screenX - 10 + sway, top + 12, tree.width * 0.48, 11, -0.3, 0, Math.PI * 2);
    ctx.fill();
  };

  const drawVines = (time: number) => {
    for (let i = 0; i < 8; i++) {
      const x = i * 151 - ((cameraX * 0.9) % 151);
      const length = 45 + (i * 31) % 72;
      ctx.strokeStyle = i % 2 ? "#408e59" : "#2d8050";
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(x, -8);
      ctx.bezierCurveTo(x + Math.sin(time + i) * 13, 35, x - 9, length * 0.5, x + Math.sin(time * 0.8 + i) * 8, length);
      ctx.stroke();
      ctx.fillStyle = "#47ad69";
      ctx.beginPath();
      ctx.ellipse(x + 9, length * 0.62, 7, 3.5, 0.45, 0, Math.PI * 2);
      ctx.fill();
    }
  };

  const drawWorld = (time: number) => {
    drawBackground(time);
    trees.forEach((tree) => drawTree(tree, time));
    drawVines(time);

    // Jungle floor and raised earth platforms.
    platforms.forEach((platform) => {
      const x = platform.x - cameraX;
      if (x > WIDTH || x + platform.width < 0) return;
      const isGround = platform.y >= GROUND_Y;
      ctx.fillStyle = isGround ? "#8e5937" : "#a96a3e";
      roundedRect(ctx, x, platform.y, platform.width, platform.height, isGround ? 0 : 9);
      ctx.fill();
      ctx.fillStyle = isGround ? "#4d9d4d" : "#58b34f";
      roundedRect(ctx, x, platform.y - 7, platform.width, isGround ? 17 : 12, isGround ? 2 : 8);
      ctx.fill();
      if (!isGround) {
        ctx.fillStyle = "rgba(255, 202, 119, .32)";
        roundedRect(ctx, x + 10, platform.y + 8, platform.width - 20, 4, 2);
        ctx.fill();
        for (let i = 0; i < 4; i++) {
          ctx.fillStyle = i % 2 ? "#47a143" : "#70c45a";
          ctx.beginPath();
          ctx.ellipse(x + 18 + i * 42, platform.y - 6, 10, 4, -0.35, 0, Math.PI * 2);
          ctx.fill();
        }
      }
    });

    rocks.forEach(([worldX, y, size], index) => {
      const x = worldX - cameraX;
      if (x < -size - 12 || x > WIDTH + size + 12) return;
      ctx.fillStyle = index % 2 ? "#858d75" : "#9a9b7a";
      ctx.beginPath();
      ctx.ellipse(x, y, size, size * 0.68, -0.16, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "rgba(224, 224, 173, .54)";
      ctx.beginPath();
      ctx.ellipse(x - size * 0.27, y - size * 0.19, size * 0.32, size * 0.16, -0.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#56844d";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x - 5, y + 2);
      ctx.lineTo(x + 1, y - 4);
      ctx.lineTo(x + 6, y + 2);
      ctx.stroke();
    });

    drawCoins(time);
    enemies.forEach((enemy) => drawEnemy(enemy, time));
    drawTreasure(time);
    drawPlayer(time);
    drawParticles();
  };

  const drawCoins = (time: number) => {
    coins.forEach((coin) => {
      if (coin.collected) return;
      const x = coin.x - cameraX;
      if (x < -30 || x > WIDTH + 30) return;
      const bob = Math.sin(time * 3.2 + coin.phase) * 4;
      const y = coin.y + bob;
      const width = 10 + Math.abs(Math.sin(time * 2.5 + coin.phase)) * 4;
      ctx.fillStyle = "rgba(254, 183, 50, .22)";
      ctx.beginPath();
      ctx.arc(x, y, 18, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#ffc93d";
      ctx.beginPath();
      ctx.ellipse(x, y, width, 13, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#f49727";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.ellipse(x, y, width - 3, 8, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.fillStyle = "#fff0a0";
      ctx.beginPath();
      ctx.ellipse(x - width * 0.24, y - 4, Math.max(2, width * 0.2), 3, -0.4, 0, Math.PI * 2);
      ctx.fill();
    });
  };

  const drawEnemy = (enemy: Enemy, time: number) => {
    const x = enemy.x - cameraX;
    if (x < -45 || x > WIDTH + 45) return;
    const y = enemy.y + Math.sin(time * 6 + enemy.phase) * 2;
    ctx.fillStyle = "rgba(26, 70, 49, .18)";
    ctx.beginPath();
    ctx.ellipse(x, y + 26, 26, 7, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ed7951";
    ctx.beginPath();
    ctx.ellipse(x, y, 23, 18, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#ffb063";
    ctx.beginPath();
    ctx.ellipse(x - 2, y - 7, 15, 8, 0, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#fff6db";
    ctx.beginPath();
    ctx.arc(x - 8, y - 2, 4.5, 0, Math.PI * 2);
    ctx.arc(x + 5, y - 2, 4.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#294737";
    ctx.beginPath();
    ctx.arc(x - 7 + enemy.direction, y - 1, 1.8, 0, Math.PI * 2);
    ctx.arc(x + 6 + enemy.direction, y - 1, 1.8, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "#83412f";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(x, y + 3, 5, 0.2, Math.PI - 0.2);
    ctx.stroke();
    ctx.fillStyle = "#fff2dd";
    ctx.beginPath();
    ctx.ellipse(x - 14, y + 14, 7, 3, -0.3, 0, Math.PI * 2);
    ctx.ellipse(x + 13, y + 14, 7, 3, 0.3, 0, Math.PI * 2);
    ctx.fill();
  };

  const drawTreasure = (time: number) => {
    const x = 3312 - cameraX;
    if (x < -100 || x > WIDTH + 100) return;
    const glow = 0.5 + Math.sin(time * 3) * 0.15;
    const aura = ctx.createRadialGradient(x, 423, 4, x, 423, 86);
    aura.addColorStop(0, `rgba(255, 222, 97, ${glow * 0.6})`);
    aura.addColorStop(1, "rgba(255, 214, 77, 0)");
    ctx.fillStyle = aura;
    ctx.beginPath();
    ctx.arc(x, 423, 86, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#7d472b";
    roundedRect(ctx, x - 36, 424, 72, 44, 9);
    ctx.fill();
    ctx.fillStyle = "#bd7138";
    roundedRect(ctx, x - 34, 421, 68, 40, 8);
    ctx.fill();
    ctx.fillStyle = "#efb844";
    ctx.beginPath();
    ctx.moveTo(x - 36, 428);
    ctx.quadraticCurveTo(x - 31, 405, x, 405);
    ctx.quadraticCurveTo(x + 31, 405, x + 36, 428);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#e7a831";
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(x - 29, 432);
    ctx.lineTo(x + 29, 432);
    ctx.stroke();
    ctx.fillStyle = "#e9c35a";
    roundedRect(ctx, x - 6, 429, 12, 17, 3);
    ctx.fill();
    ctx.fillStyle = "#fff2a6";
    ctx.beginPath();
    ctx.arc(x, 435, 2, 0, Math.PI * 2);
    ctx.fill();
    [0, 1, 2].forEach((i) => {
      ctx.fillStyle = i === 1 ? "#ffe986" : "#efb537";
      ctx.beginPath();
      ctx.arc(x - 17 + i * 17, 416 + Math.sin(time * 2 + i) * 3, 4, 0, Math.PI * 2);
      ctx.fill();
    });
  };

  const drawPlayer = (time: number) => {
    const x = player.x - cameraX;
    if (invulnerable > 0 && Math.floor(time * 13) % 2 === 0) return;
    const bob = player.grounded ? Math.sin(time * 10) * (Math.abs(player.vx) > 0 ? 1.5 : 0.4) : 0;
    const y = player.y + bob;
    const dir = player.facing;
    ctx.save();
    ctx.translate(x, y);
    ctx.scale(dir, 1);

    ctx.fillStyle = "rgba(25, 67, 45, .2)";
    ctx.beginPath();
    ctx.ellipse(0, PLAYER_HEIGHT + 1, 21, 6, 0, 0, Math.PI * 2);
    ctx.fill();

    const stride = player.grounded ? Math.sin(time * 13) * Math.min(5, Math.abs(player.vx) * 0.025) : 0;
    ctx.strokeStyle = "#4d3325";
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(-7, 39);
    ctx.lineTo(-9 - stride, 48);
    ctx.moveTo(7, 39);
    ctx.lineTo(8 + stride, 48);
    ctx.stroke();
    ctx.fillStyle = "#5a3828";
    roundedRect(ctx, -16 - stride, 45, 12, 6, 3);
    ctx.fill();
    roundedRect(ctx, 3 + stride, 45, 13, 6, 3);
    ctx.fill();

    ctx.fillStyle = "#a05c3c";
    roundedRect(ctx, 10, 18, 13, 21, 6);
    ctx.fill();
    ctx.fillStyle = "#ce7747";
    roundedRect(ctx, -13, 17, 26, 25, 8);
    ctx.fill();
    ctx.fillStyle = "#f0ca83";
    roundedRect(ctx, -8, 25, 16, 14, 5);
    ctx.fill();
    ctx.strokeStyle = "#f6e1ad";
    ctx.lineWidth = 5;
    ctx.beginPath();
    ctx.moveTo(10, 23);
    ctx.lineTo(17, 31);
    ctx.stroke();

    ctx.fillStyle = "#d89156";
    ctx.beginPath();
    ctx.arc(0, 12, 13, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#efc789";
    ctx.beginPath();
    ctx.ellipse(5, 16, 8, 5, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#243d31";
    ctx.beginPath();
    ctx.arc(7, 11, 2, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#54362a";
    ctx.beginPath();
    ctx.arc(11, 16, 1.8, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#f6d15e";
    ctx.beginPath();
    ctx.ellipse(0, 1, 17, 7, -0.04, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#4e9e55";
    ctx.beginPath();
    ctx.ellipse(-1, -2, 17, 8, -0.04, Math.PI, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#3c8348";
    roundedRect(ctx, -11, -5, 15, 4, 2);
    ctx.fill();

    ctx.restore();
  };

  const drawParticles = () => {
    particles.forEach((particle) => {
      ctx.globalAlpha = clamp(particle.life / 0.6, 0, 1);
      ctx.fillStyle = particle.color;
      ctx.beginPath();
      ctx.arc(particle.x - cameraX, particle.y, particle.size, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.globalAlpha = 1;
  };

  const burst = (x: number, y: number, color: string, count: number) => {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + Math.random() * 0.3;
      const speed = 65 + Math.random() * 155;
      particles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed - 40,
        life: 0.38 + Math.random() * 0.28,
        color,
        size: 2 + Math.random() * 3,
      });
    }
  };

  const update = (dt: number) => {
    if (status !== "playing") return;
    elapsed += dt;
    timeSeconds = Math.floor(elapsed);
    hitCooldown = Math.max(0, hitCooldown - dt);
    invulnerable = Math.max(0, invulnerable - dt);

    const movingLeft = keys.has("arrowleft") || keys.has("a");
    const movingRight = keys.has("arrowright") || keys.has("d");
    const direction = Number(movingRight) - Number(movingLeft);
    player.vx = direction * 245;
    if (direction) player.facing = direction;
    player.x = clamp(player.x + player.vx * dt, 12, LEVEL_WIDTH - 62);

    const oldBottom = player.y + PLAYER_HEIGHT;
    player.vy = Math.min(900, player.vy + 1700 * dt);
    player.y += player.vy * dt;
    player.grounded = false;

    // Land only when crossing a platform from above so jumping remains predictable.
    let landingPlatform: Platform | undefined;
    for (const platform of platforms) {
      const overlapsHorizontally =
        player.x + PLAYER_WIDTH * 0.35 > platform.x &&
        player.x - PLAYER_WIDTH * 0.35 < platform.x + platform.width;
      const newBottom = player.y + PLAYER_HEIGHT;
      if (
        overlapsHorizontally &&
        player.vy >= 0 &&
        oldBottom <= platform.y + 2 &&
        newBottom >= platform.y
      ) {
        if (!landingPlatform || platform.y < landingPlatform.y) {
          landingPlatform = platform;
        }
      }
    }
    if (landingPlatform) {
      player.y = landingPlatform.y - PLAYER_HEIGHT;
      player.vy = 0;
      player.grounded = true;
    }

    cameraX = clamp(player.x - WIDTH * 0.43, 0, LEVEL_WIDTH - WIDTH);

    coins.forEach((coin) => {
      if (coin.collected) return;
      const bob = Math.sin(elapsed * 3.2 + coin.phase) * 4;
      const dx = player.x - coin.x;
      const dy = player.y + PLAYER_HEIGHT * 0.48 - (coin.y + bob);
      if (dx * dx + dy * dy < 34 * 34) {
        coin.collected = true;
        score += 10;
        burst(coin.x, coin.y + bob, "#ffd44d", 8);
      }
    });

    enemies.forEach((enemy) => {
      enemy.x += enemy.speed * enemy.direction * dt;
      if (enemy.x < enemy.min || enemy.x > enemy.max) {
        enemy.direction *= -1;
        enemy.x = clamp(enemy.x, enemy.min, enemy.max);
      }
      const dx = Math.abs(player.x - enemy.x);
      const dy = Math.abs(player.y + PLAYER_HEIGHT * 0.55 - (enemy.y + 4));
      if (dx < 38 && dy < 34 && hitCooldown <= 0 && invulnerable <= 0) {
        health -= 1;
        hitCooldown = 1.15;
        invulnerable = 1.45;
        player.vy = -360;
        player.vx = player.x < enemy.x ? -250 : 250;
        burst(player.x, player.y + 24, "#ffa16d", 9);
        if (health <= 0) {
          health = 0;
          status = "lost";
        }
      }
    });

    particles.forEach((particle) => {
      particle.x += particle.vx * dt;
      particle.y += particle.vy * dt;
      particle.vy += 390 * dt;
      particle.life -= dt;
    });
    for (let i = particles.length - 1; i >= 0; i--) {
      if (particles[i].life <= 0) particles.splice(i, 1);
    }

    if (Math.abs(player.x - 3312) < 50 && player.y + PLAYER_HEIGHT > GROUND_Y - 85) {
      status = "won";
      score += 100;
      burst(3312, 414, "#ffdc59", 26);
    }
  };

  const render = (timestamp: number) => {
    if (disposed) return;
    if (!lastFrame) lastFrame = timestamp;
    const dt = Math.min((timestamp - lastFrame) / 1000, 1 / 24);
    lastFrame = timestamp;
    const previousStatus = status;
    const previousScore = score;
    const previousHealth = health;
    update(dt);
    drawWorld(timestamp / 1000);
    if (
      status !== previousStatus ||
      score !== previousScore ||
      health !== previousHealth ||
      (status === "playing" && timeSeconds !== lastPublishedSecond)
    ) {
      lastPublishedSecond = timeSeconds;
      publish();
    }
    frameId = window.requestAnimationFrame(render);
  };

  const observer = new ResizeObserver(resize);
  observer.observe(canvas);
  resize();
  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", onBlur);
  publish();
  frameId = window.requestAnimationFrame(render);

  return {
    start() {
      if (status === "ready") reset(true);
    },
    restart() {
      reset(true);
    },
    destroy() {
      disposed = true;
      window.cancelAnimationFrame(frameId);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      observer.disconnect();
    },
  };
}
