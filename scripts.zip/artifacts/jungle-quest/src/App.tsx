import { useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  ArrowLeftRight,
  ArrowUp,
  Backpack,
  ChevronRight,
  Clock3,
  Compass,
  Crown,
  Gem,
  Heart,
  Leaf,
  Map,
  Play,
  RotateCcw,
  Sparkles,
  Star,
  Trophy,
} from 'lucide-react';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Route,
  Switch,
  useLocation,
  Router as WouterRouter,
} from 'wouter';
import { createJungleGame, type GameSnapshot, type JungleGameController } from './game/engine';

const queryClient = new QueryClient();

const initialSnapshot: GameSnapshot = {
  status: 'ready',
  score: 0,
  health: 3,
  coinsCollected: 0,
  coinsTotal: 24,
  timeSeconds: 0,
};

function formatTime(totalSeconds: number) {
  const minutes = Math.floor(totalSeconds / 60).toString().padStart(2, '0');
  const seconds = Math.floor(totalSeconds % 60).toString().padStart(2, '0');
  return `${minutes}:${seconds}`;
}

function Home() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const controllerRef = useRef<JungleGameController | null>(null);
  const [snapshot, setSnapshot] = useState<GameSnapshot>(initialSnapshot);

  useLayoutEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const controller = createJungleGame(canvas, (nextSnapshot) => setSnapshot(nextSnapshot));
    controllerRef.current = controller;
    return () => {
      controller.destroy();
      controllerRef.current = null;
    };
  }, []);

  const beginGame = () => controllerRef.current?.start();
  const restartGame = () => controllerRef.current?.restart();
  const health = Math.max(0, Math.min(3, snapshot.health));
  const coinPercent = snapshot.coinsTotal > 0
    ? Math.min(100, (snapshot.coinsCollected / snapshot.coinsTotal) * 100)
    : 0;
  const ended = snapshot.status === 'won' || snapshot.status === 'lost';

  return (
    <main className="game-page">
      <div className="shell">
        <header className="topbar">
          <div className="brand" aria-label="Jungle Quest game">
            <div className="brand-mark"><Compass size={25} strokeWidth={2.2} /></div>
            <div>
              <div className="brand-name">Jungle Quest</div>
              <div className="brand-kicker">The Lost Treasure · Expedition 01</div>
            </div>
          </div>
          <div className="top-note"><Sparkles size={15} /><span>A little adventure goes a long way</span></div>
        </header>

        <div className="game-layout">
          <section className="play-column" aria-label="Jungle adventure game">
            <div className="hud" aria-label="Game status">
              <div className="hud-card" data-testid="status-score">
                <div className="hud-icon gold"><Star size={19} fill="currentColor" /></div>
                <div className="hud-copy">
                  <div className="hud-label">Score</div>
                  <div className="hud-value">{snapshot.score.toLocaleString()}</div>
                </div>
              </div>
              <div className="hud-card" data-testid="status-health" aria-label={`Health: ${health} of 3`}>
                <div className="hud-icon heart"><Heart size={19} fill="currentColor" /></div>
                <div className="hud-copy">
                  <div className="hud-label">Health</div>
                  <div className="health-dots" aria-hidden="true">
                    {[0, 1, 2].map((heart) => (
                      <span key={heart} className={`health-dot${heart >= health ? ' empty' : ''}`} />
                    ))}
                  </div>
                </div>
              </div>
              <div className="hud-card" data-testid="status-coins">
                <div className="hud-icon gold"><Gem size={19} /></div>
                <div className="hud-copy">
                  <div className="hud-label">Coins</div>
                  <div className="hud-value">{snapshot.coinsCollected}<small> / {snapshot.coinsTotal}</small></div>
                </div>
              </div>
              <div className="hud-card" data-testid="status-time">
                <div className="hud-icon"><Clock3 size={19} /></div>
                <div className="hud-copy">
                  <div className="hud-label">Elapsed</div>
                  <div className="hud-value">{formatTime(snapshot.timeSeconds)}</div>
                </div>
              </div>
            </div>

            <div className="canvas-frame" data-testid="game-canvas-frame">
              <canvas
                ref={canvasRef}
                className="game-canvas"
                width={960}
                height={540}
                aria-label="Jungle Quest playfield. Use left and right or A and D to move, and Space to jump."
                data-testid="game-canvas"
              />

              {snapshot.status === 'playing' && (
                <div className="playing-pill" data-testid="status-playing" aria-live="polite">
                  <span className="live-dot" /> Expedition in progress
                </div>
              )}

              {snapshot.status !== 'playing' && (
                <div className="state-overlay" data-testid={`overlay-${snapshot.status}`}>
                  <div className="overlay-card" role="group" aria-labelledby="overlay-title">
                    <div className="overlay-seal">
                      {snapshot.status === 'ready' && <Map size={25} />}
                      {snapshot.status === 'won' && <Trophy size={25} />}
                      {snapshot.status === 'lost' && <Leaf size={25} />}
                    </div>
                    <div className="overline">
                      {snapshot.status === 'ready' && 'Your expedition awaits'}
                      {snapshot.status === 'won' && 'Treasure found'}
                      {snapshot.status === 'lost' && 'Game over'}
                    </div>
                    <h1 className="overlay-title" id="overlay-title">
                      {snapshot.status === 'ready' && <>The Lost<br />Treasure</>}
                      {snapshot.status === 'won' && 'You found it!'}
                      {snapshot.status === 'lost' && 'Adventure over'}
                    </h1>
                    <p className="overlay-copy">
                      {snapshot.status === 'ready' && 'Leap through the canopy, gather every golden coin, and find the treasure hidden deep in the green.'}
                      {snapshot.status === 'won' && `A brilliant expedition. You scored ${snapshot.score.toLocaleString()} points and gathered ${snapshot.coinsCollected} coin${snapshot.coinsCollected === 1 ? '' : 's'}.`}
                      {snapshot.status === 'lost' && 'Take a breath, explorer. There are more paths through the jungle and another chance at the treasure.'}
                    </p>
                    {snapshot.status === 'ready' && (
                      <>
                        <button className="action-button" type="button" onClick={beginGame} data-testid="button-start">
                          <Play size={17} fill="currentColor" /> Start expedition <ChevronRight size={17} />
                        </button>
                        <span className="overlay-hint">Press the button or use the keyboard controls below</span>
                      </>
                    )}
                    {ended && (
                      <>
                        <button className="action-button" type="button" onClick={restartGame} data-testid="button-restart">
                          <RotateCcw size={17} /> Play again <ChevronRight size={17} />
                        </button>
                        <span className="overlay-hint">Ready when you are, explorer</span>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>

            <div className="underbar">
              <div className="controls-line" aria-label="Controls">
                <span className="control-group"><kbd className="key">←</kbd><kbd className="key">→</kbd><span>or</span><kbd className="key">A</kbd><kbd className="key">D</kbd><span>move</span></span>
                <span className="control-divider" />
                <span className="control-group"><kbd className="key">Space</kbd><span>jump</span></span>
              </div>
              <div className="tiny-caption"><ArrowLeftRight size={13} /> Keyboard controls</div>
            </div>
          </section>

          <aside className="side-panel" aria-label="Expedition guide">
            <h2 className="panel-heading"><Backpack size={19} /> Field guide</h2>
            <div className="mission-card">
              <div className="mission-eyebrow">Current mission</div>
              <div className="mission-name">The Canopy Trail</div>
              <div className="mission-desc">A forgotten path winds beneath the ancient trees. Keep your eyes open.</div>
            </div>
              <div className="section-label"><span>Coins gathered</span><span className="progress-count">{snapshot.coinsCollected}/{snapshot.coinsTotal}</span></div>
            <div className="coin-track" role="progressbar" aria-label="Relics gathered" aria-valuemin={0} aria-valuemax={snapshot.coinsTotal} aria-valuenow={snapshot.coinsCollected}>
              <div className="coin-progress" style={{ width: `${coinPercent}%` }} />
            </div>
            <div className="section-label"><span>Trail notes</span><span>01 / 03</span></div>
            <ul className="objective-list">
              <li className="objective"><span className="objective-bullet"><Gem size={11} /></span><span>Gather the <strong>golden coins</strong> scattered along the trail.</span></li>
              <li className="objective"><span className="objective-bullet"><ArrowUp size={11} /></span><span>Time your jumps to cross <strong>gaps and high ledges.</strong></span></li>
              <li className="objective"><span className="objective-bullet"><Crown size={11} /></span><span>Reach the <strong>treasure chest</strong> at the end of the path.</span></li>
            </ul>
            <div className="expedition-note">
              <strong>Explorer's tip</strong>
              A little momentum helps you reach the far platforms. Watch your step around the wildlife.
            </div>
            <div className="side-foot"><span>Map updated</span><span>·</span><span>Just now</span></div>
          </aside>
        </div>
      </div>
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Home} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
